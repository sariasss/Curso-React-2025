
//traer data de un pokemon
export const getPokemonHandler = (req, res) =>{
    const { name } = req.params;
    getPokemon(name, (err, rows) => {
        if(err){
            res.status(500).json({error:err.message});
        }else{
            res.status(200).json(rows);
        }
    });
} 
